import "./styles.css";
import { ToDo } from "./components/ToDo";
export default function App() {
  return (
    <div id="body">
      <ToDo />
    </div>
  );
}
